# room_config.py
from dataclasses import dataclass
from typing import Dict, List, Tuple, Optional
from enum import Enum

class DetectionMethod(Enum):
    PIXEL_COLOR = "pixel_color"
    TEMPLATE_MATCHING = "template_matching"
    OCR = "ocr"

@dataclass
class DealerConfig:
    """
    Usa apenas a cor de 1 pixel, definido em color_rgb
    """
    detection_method: DetectionMethod
    positions: Dict[int, Tuple[int, int]]  # Position number -> (x, y)
    color_rgb: Optional[Tuple[int, int, int]] = None  # For pixel color
    color_threshold: Optional[int] = None  # For pixel color

@dataclass
class ROIConfig:
    stacks: Dict[str, List[int]]  # name -> [x, y, w, h]
    bets: Dict[str, List[int]]
    names: Dict[str, List[int]]
    pot: Dict[str, List[int]]
    smallpot: Dict[str, List[int]]
    money_exists: Dict[bool, List[bool]]

@dataclass
class PlayerDetectionConfig:
    detection_method: DetectionMethod
    positions: Dict[int, List[int]]  # Position number -> [x, y, w, h]
    threshold: float = 0.8

@dataclass
class RoomConfig:
    debug_mode = True
    room_id: str
    room_name: str
    dealer_config: DealerConfig
    roi_config: ROIConfig
    player_detection_config: PlayerDetectionConfig
    template_path: Optional[str] = None
    sample_image_path:  Optional[str] = None
    big_blind: Optional[float] = 0.04

# rooms/swc_poker.py
def get_swc_poker_config() -> RoomConfig:
    template_path = "imgs/models/swc/"
    return RoomConfig(
        room_id="swc_poker",
        room_name="SwC Poker",
        template_path = template_path,
        sample_image_path = template_path + "table_example.png",
        dealer_config=DealerConfig(
            detection_method=DetectionMethod.PIXEL_COLOR,
            positions={
                0: (350, 416),
                1: (663, 387),
                2: (626, 296),
                3: (617, 207),
                4: (506, 154),
                5: (302, 154),
                6: (194, 207),
                7: (179, 301),
                8: (148, 387),
            },
            color_rgb=(224, 216, 195),  #BGR - Blue - Green - Red
            color_threshold=30
        ),
        roi_config=ROIConfig(
            stacks={
                "stack_0": [390, 470, 110, 16],
                "stack_1": [514, 441, 110, 16],
                "stack_2": [642, 348, 110, 16],
                "stack_3": [642, 244, 110, 16],
                "stack_4": [537, 139, 110, 16],
                "stack_5": [182, 139, 110, 16],
                "stack_6": [77, 244, 110, 16],
                "stack_7": [79, 348, 110, 16],
                "stack_8": [205, 441, 110, 16],
            },
            bets={
                "bet_0": [433, 370, 61, 30],
                "bet_1": [481, 339, 61, 30],
                "bet_2": [530, 308, 61, 30],
                "bet_3": [578, 256, 61, 30],
                "bet_4": [531, 190, 61, 30],
                "bet_5": [230, 190, 61, 30],
                "bet_6": [190, 256, 61, 30],
                "bet_7": [221, 308, 61, 30],
                "bet_8": [266, 339, 61, 30],
            },
            names={
                "name_0": [390, 450, 109, 15],
                "name_1": [514, 421, 109, 15],
                "name_2": [642, 328, 109, 15],
                "name_3": [642, 224, 109, 15],
                "name_4": [537, 118, 109, 15],
                "name_5": [182, 118, 109, 15],
                "name_6": [77, 224, 109, 15],
                "name_7": [78, 328, 108, 15],
                "name_8": [205, 421, 109, 15],
            },
            pot={
                "pot": [360, 200, 110, 13],
            },
            smallpot={
                "smallpot": [355, 325, 118, 17],
            },
            money_exists={
                "player_7": [158, 119, 13], 
            }
        ),
        player_detection_config=PlayerDetectionConfig(
            detection_method=DetectionMethod.TEMPLATE_MATCHING,
            positions={
                0: [396, 471, 35, 12],
                1: [589, 441, 35, 12],
                2: [717, 349, 35, 12],
                3: [717, 245, 35, 12],
                4: [612, 140, 35, 12],
                5: [179, 140, 35, 12],
                6: [74, 245, 35, 12],
                7: [74, 349, 35, 12],
                8: [202, 441, 35, 12]
            },
            threshold=0.8
        )
    )

# rooms/bodog_poker.py
def get_bodog_poker_config() -> RoomConfig:
    return RoomConfig(
        room_id="bodog_poker",
        room_name="Bodog Poker",
        template_path="imgs/models/others/OPEN.png",
        dealer_config=DealerConfig(
            detection_method=DetectionMethod.PIXEL_COLOR,
            positions={
                0: (350, 416),
                1: (663, 387),
                2: (626, 296),
                3: (617, 207),
                4: (506, 154),
                5: (302, 154),
                6: (194, 207),
                7: (179, 301),
                8: (148, 387),
            },
            color_rgb=(224, 216, 195),  # RGB format
            color_threshold=20
        ),
        roi_config=ROIConfig(
            stacks={
                "stack_0": [390, 470, 110, 16],
                "stack_1": [514, 441, 110, 16],
                "stack_2": [642, 348, 110, 16],
                "stack_3": [642, 244, 110, 16],
                "stack_4": [537, 139, 110, 16],
                "stack_5": [182, 139, 110, 16],
                "stack_6": [77, 244, 110, 16],
                "stack_7": [79, 348, 110, 16],
                "stack_8": [205, 441, 110, 16],
            },
            bets={
                "bet_0": [433, 370, 61, 30],
                "bet_1": [481, 339, 61, 30],
                "bet_2": [530, 308, 61, 30],
                "bet_3": [578, 256, 61, 30],
                "bet_4": [531, 190, 61, 30],
                "bet_5": [200, 190, 61, 30],
                "bet_6": [190, 256, 61, 30],
                "bet_7": [221, 308, 61, 30],
                "bet_8": [266, 339, 61, 30],
            },
            names={
                "name_0": [390, 450, 109, 15],
                "name_1": [514, 421, 109, 15],
                "name_2": [642, 328, 109, 15],
                "name_3": [642, 224, 109, 15],
                "name_4": [537, 118, 109, 15],
                "name_5": [182, 118, 109, 15],
                "name_6": [77, 224, 109, 15],
                "name_7": [79, 328, 109, 15],
                "name_8": [205, 421, 109, 15],
            },
            pot={
                "pot": [360, 200, 110, 13],
            },
            smallpot={
                "smallpot": [355, 325, 118, 17],
            }
        ),
        player_detection_config=PlayerDetectionConfig(
            detection_method=DetectionMethod.TEMPLATE_MATCHING,
            positions={
                0: [396, 471, 35, 12],
                1: [589, 441, 35, 12],
                2: [717, 349, 35, 12],
                3: [717, 245, 35, 12],
                4: [612, 140, 35, 12],
                5: [179, 140, 35, 12],
                6: [74, 245, 35, 12],
                7: [74, 349, 35, 12],
                8: [202, 441, 35, 12]
            },

            threshold=0.8
        )
    )


def get_acr_poker_config() -> RoomConfig:
    return RoomConfig(
        room_id="acr_poker",
        room_name="ACR Poker",
        template_path="imgs/models/acr/",
        sample_image_path="imgs/models/acr/table_example.png",
        dealer_config=DealerConfig(
            detection_method=DetectionMethod.PIXEL_COLOR,
            positions={
                0: (350, 416),
                1: (663, 387),
                2: (626, 296),
                3: (617, 207),
                4: (506, 154),
                5: (302, 154),
                6: (194, 207),
                7: (179, 301),
                8: (148, 387),
            },
            color_rgb=(224, 216, 195),  # RGB format
            color_threshold=30
        ),
        roi_config=ROIConfig(
            stacks={
                "stack_0": [390, 470, 110, 16],
                "stack_1": [514, 441, 110, 16],
                "stack_2": [642, 348, 110, 16],
                "stack_3": [642, 244, 110, 16],
                "stack_4": [537, 139, 110, 16],
                "stack_5": [182, 139, 110, 16],
                "stack_6": [77, 244, 110, 16],
                "stack_7": [79, 348, 110, 16],
                "stack_8": [205, 441, 110, 16],
            },
            bets={
                "bet_0": [433, 370, 61, 30],
                "bet_1": [481, 339, 61, 30],
                "bet_2": [530, 308, 61, 30],
                "bet_3": [578, 256, 61, 30],
                "bet_4": [531, 190, 61, 30],
                "bet_5": [230, 190, 61, 30],
                "bet_6": [190, 256, 61, 30],
                "bet_7": [221, 308, 61, 30],
                "bet_8": [266, 339, 61, 30],
            },
            names={
                "name_0": [390, 450, 109, 15],
                "name_1": [514, 421, 109, 15],
                "name_2": [642, 328, 109, 15],
                "name_3": [642, 224, 109, 15],
                "name_4": [537, 118, 109, 15],
                "name_5": [182, 118, 109, 15],
                "name_6": [77, 224, 109, 15],
                "name_7": [79, 328, 109, 15],
                "name_8": [205, 421, 109, 15],
            },
            pot={
                "pot": [360, 200, 110, 13],
            },
            smallpot={
                "smallpot": [355, 325, 118, 17],
            },
            money_exists={
                True: [True, True, True, True, True, True, True, True, True],
            }
        ),
        player_detection_config=PlayerDetectionConfig(
            detection_method=DetectionMethod.TEMPLATE_MATCHING,
            positions={
                0: [396, 471, 35, 12],
                1: [589, 441, 35, 12],
                2: [717, 349, 35, 12],
                3: [717, 245, 35, 12],
                4: [612, 140, 35, 12],
                5: [179, 140, 35, 12],
                6: [74, 245, 35, 12],
                7: [74, 349, 35, 12],
                8: [202, 441, 35, 12]
            },
            threshold=0.8
        )
    )