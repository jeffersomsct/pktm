
from numpy import show_config
from core.window_handler import search_parent_window
from images.capture import snapshot
import numpy as np
import cv2
from rooms.poker_room import PokerRoom
from colorama import Fore, Style, init
init()

def detect_window(poker_room: str) ->  np.ndarray:
    """
    Captura as janelas filhas através da janela principal ("Lobby")
    e retorna uma imagem no formato BGR para processamento com OpenCV
    """
    
    visible_widow = search_parent_window(poker_room)
    # remover a janela principal ("Lobby")
    visible_widow = [t for t in visible_widow if poker_room not in t[1]]
    
    # Verificar se há janelas para capturar
    if not visible_widow:
        print("Nenhuma janela de poker encontrada!")
        return np.zeros((100, 100, 3), dtype=np.uint8)  # Retorna imagem vazia se não houver janelas
    
    # Capturar as janelas
    snap_shot = snapshot(visible_widow)
    
    # Verificar se a captura retornou alguma imagem
    if not snap_shot or len(snap_shot) == 0:
        print("Falha ao capturar janelas!")
        return np.zeros((100, 100, 3), dtype=np.uint8)  # Retorna imagem vazia em caso de falha
    
    # Usar a primeira imagem capturada (poderia ser modificado para combinar múltiplas imagens se necessário)
    img = snap_shot[0]
    
    # Converter diretamente para BGR para evitar conversões desnecessárias
    # Isso é mais rápido que converter para RGB e depois para BGR
    image_bgr = cv2.cvtColor(np.array(img, dtype=np.uint8), cv2.COLOR_RGB2BGR)
    
    return image_bgr

def print_players_table(players):
    header =    f"+--------------+----------+---------+----------------+------------------+-----------+----------+------------+------------+"
    title =     f"| Nome         | Posição  |  Stack  |   Aposta Atual | Posição Pré-flop | Is Present| Is Active| Just Joined| Pending BB |"
    separator = f"+==============+==========+=========+================+==================+===========+==========+============+============+"
    
    print(f"\n{Fore.CYAN}{header}{Style.RESET_ALL}")
    print(f"{Fore.CYAN}{title}{Style.RESET_ALL}")
    print(f"{Fore.CYAN}{separator}{Style.RESET_ALL}")
    
    for p in players:
        name_color = Fore.GREEN if p.is_present else Fore.RED
        present_color = Fore.GREEN if p.is_present else Fore.RED
        active_color = Fore.GREEN if p.is_active else Fore.RED
        
        # Ajustando as larguras para bater com o cabeçalho
        nome = f"{name_color}{p.name:<12}{Style.RESET_ALL}"        
        posicao = f"{p.position:>8}"                                
        stack = f"{p.stack:>7.2f}"                               
        aposta = f"{p.current_bet:>14.2f}"                        
        pos_preflop = f"{(p.pos_preflop or 'N/A'):<16}"            
        is_present = f"{present_color}{str(p.is_present):<9}{Style.RESET_ALL}"  
        is_active = f"{active_color}{str(p.is_active):<8}{Style.RESET_ALL}"    
        just_joined = f"{str(p.just_joined):<10}"                
        pending_bb = f"{str(p.pending_big_blind):<10}"           
        
        linha = f"| {nome} | {posicao} | {stack} | {aposta} | {pos_preflop} | {is_present} | {is_active} | {just_joined} | {pending_bb} |"
        print(linha)
    
    print(f"{Fore.CYAN}{separator}{Style.RESET_ALL}")

def print_table_status(table_info, players):
    # Informações gerais da mesa
    dealer_pos = table_info.table_state.dealer_position
    pot = table_info.table_state.pot
    small_pot = table_info.table_state.small_pot
    
    # Cabeçalho criativo da mesa
    print(f"\n{Fore.YELLOW}╔═══════════════════════════════════════════════════════════════════════════════════════════╗")
    print(f"║{Fore.CYAN}                            🎲 MESA DE POKER - STATUS ATUAL                                {Fore.YELLOW}║")
    print(f"╠═══════════════════════════════════════════════════════════════════════════════════════════╣")
    print(f"║ {Fore.WHITE}Dealer: Posição {Fore.GREEN}{dealer_pos}{Fore.WHITE} {'🃏'*3}  |  Pote Principal: {Fore.GREEN}${pot}{Fore.WHITE} {'💰'*3}  |  Pote Secundário: {Fore.YELLOW}{small_pot if small_pot else 'N/A'}{Fore.WHITE} {Fore.YELLOW}       ║")
    print(f"╚═══════════════════════════════════════════════════════════════════════════════════════════╝{Style.RESET_ALL}")
    



def main():
    pkr_room = "SwC Poker - usuário jeffpk"  # Can be changed to other supported rooms
    live = False
    
    # Create room instance
    room = PokerRoom(pkr_room)
    
    # Get table snapshot
    if live:
        snapshot = detect_window(room.config.room_name)
    else:
        snapshot = None
        
    # Analyze table
    table_info = room.analyze_table(snapshot)
    
  
    print_players_table(table_info.table_state.players)
    print_table_status(table_info, table_info.table_state.players)

if __name__ == "__main__":
    main()


