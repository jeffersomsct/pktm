import asyncio
import winrt.windows.graphics.capture as capture
import winrt.windows.graphics.directx as directx
import winrt.windows.foundation as foundation
import winrt.windows.system as system
import winrt.windows.ui.core as core
import win32gui

# Função para encontrar a janela com base no título
def find_window_by_title(title):
    hwnd = win32gui.FindWindow(None, title)
    if hwnd == 0:
        print("Janela não encontrada!")
        return None
    return hwnd

# Função para capturar a janela "Calculadora" usando WinRT
async def capture_calculator_window(window_title="Calculadora"):
    hwnd = find_window_by_title(window_title)
    if hwnd is None:
        return
    
    # Obter a posição e o tamanho da janela
    left, top, right, bottom = win32gui.GetWindowRect(hwnd)
    width = right - left
    height = bottom - top
    
    # Criar uma captura gráfica usando WinRT
    print(f"Iniciando captura da janela: {window_title}")
    
    # Criando um Direct3D11Device para captura
    device = directx.Direct3D11Device()
    
    # Configurar a captura de gráficos para a janela
    frame_pool = capture.GraphicsCaptureFramePool.create(device)
    
    # Captura da janela específica
    capture_item = await capture.GraphicsCapturePicker().pick_single_item_async()
    
    if capture_item is None:
        print("Seleção de captura não foi bem-sucedida.")
        return
    
    # Criação da sessão de captura
    capture_session = capture.GraphicsCaptureSession()
    capture_session.start_capture(capture_item)
    
    # Captura de uma tela
    frame = capture_session.get_current_frame()
    
    # Processar a captura para salvar como uma imagem
    image_data = frame.surface.to_image_data()
    
    # Salvar a imagem
    with open("calculadora_capture.png", "wb") as f:
        f.write(image_data)
    
    print("Captura da janela 'Calculadora' salva como 'calculadora_capture.png'.")

# Função principal para rodar o código
def main():
    asyncio.run(capture_calculator_window("Calculadora"))

if __name__ == "__main__":
    main()
