import numpy as np
from pathlib import Path
from enum import Enum
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from core.blinds_manager import BlindsManager
from config.room_config import RoomConfig
from core.window_handler import search_parent_window
from images.capture import snapshot
import cv2
from codemap import Position
import os
from datetime import datetime



@dataclass
class Player:
    name: str
    position: int
    pos_preflop: Position
    is_present: bool
    is_active: bool
    stack: float
    current_bet: float
    just_joined: bool = False
    pending_big_blind: bool = False


@dataclass
class TableState:
    players: Player
    pot: str
    small_pot: str
    dealer_position: int



class RecognitionCategory(Enum):
    STACK = 'stack'
    BET = 'bet'
    POT = 'pot'
    SMALLPOT = 'smallpot'
    NAMES = 'names'

class CharacterRecognizer:
    def __init__(self, template_path):
        self.base_path = Path(template_path)
        self.templates: Dict[str, List] = {}
        self.target_size = (32, 32)
        self.threshold = 0.8

    def _get_template_mapping(self, category: RecognitionCategory) -> Dict[str, List[str]]:
        mappings = {
            RecognitionCategory.STACK: {'0': ['0.png'], '1': ['1.png'], '2': ['2.png', '2v2.png'], '3': ['3.png'], '4': ['4.png'],  '4': ['4_v2.png'],'5': ['5v2.png'], '6': ['6.png', '6_v2.png'], '7': ['7v2.png'], '8': ['8.png', '8_v2.png'], '9': ['9v2.png'], '.': ['ponto.png', 'ponto_v2.png'], '':['nada.png']},
            RecognitionCategory.BET: {'0': ['0.png'], '1': ['1.png'], '2': ['2.png'], '3': ['3.png'], '4': ['4.png'],'5': ['5.png'],'6': ['6.png'],'7': ['7.png'], '8': ['8.png'], '9': ['9.png'], '.': ['ponto.png']},
            RecognitionCategory.POT: {'0': ['0.png'], '1': ['1.png'], '2': ['2.png'], '3': ['3.png'], '4': ['4.png'],'5': ['5.png'],'6': ['6.png'],'7': ['7.png'], '8': ['8.png'], '9': ['9.png'], '.': ['ponto.png']},
            RecognitionCategory.SMALLPOT: {'0': ['0.png'], '1': ['1.png'], '2': ['2.png'], '3': ['3.png'], '4': ['4.png'],'5': ['5.png'],'6': ['6.png'],'7': ['7.png'], '8': ['8.png'], '9': ['9.png'], '.': ['ponto.png']},
            RecognitionCategory.NAMES: {'A': ['A.png'],'a': ['a_.png', 'a_v2.png'], 'b': ['b_.png'], 'B': ['B.png'], 'C': ['C.png'],'c': ['c_.png'], 'D': ['D.png'], 'd': ['d_.png', 'd_v2.png'],'e': ['e_.png', 'e_v2.png'], 'f': ['f_.png'], 'G': ['G.png'], 'g': ['g_.png'],'h': ['h_.png', 'h_v2.png'], 'i': ['i_.png'], 'j': ['j_.png'], 'k': ['k_.png', 'k_v2.png'], 'L': ['L.png'], 'l': ['l_.png', 'l_v2.png'], 'M': ['M.png'],'m': ['m_.png'], 'N': ['N.png'], 'n': ['n_.png', 'n_v2.png', 'n_v3.png'], 'O': ['O.png'], 'o': ['o_.png', 'o_v2.png'], 'P': ['P.png'], 'p': ['p_.png'], 'Q': ['Q.png'], 'r': ['r_.png'], 'S': ['S.png', 'Sv2.png'], 's': ['s_.png'], 'T': ['T.png'], 't': ['t_.png'], 'U': ['U.png','Uv2.png'],'u': ['u_.png'], 'v': ['v_.png'],'w': ['w_.png', 'w_v2.png'],'y': ['y_.png','y_v2.png'], 'Z': ['Z.png'], 'z': ['Z_.png'], '0': ['0.png'], '2': ['2.png'],'3': ['3.png'], '5': ['5.png'],  '7': ['7.png'],  '9': ['9.png', '9v2.png']},
        }
        return mappings.get(category, {})

    def load_templates(self, category: RecognitionCategory):
        print(f"Carregando templates para categoria: {category.value}\n")
        self.templates.clear()
        template_dir = self.base_path / category.value
        # template_dir = self.base_path
        if not template_dir.exists():
            raise ValueError(f"Diretório de templates não encontrado: {template_dir}")

        template_mapping = self._get_template_mapping(category)

        for char, template_files in template_mapping.items():
            template_list = []
            for template_file in template_files:
                template_path = template_dir / template_file
                if template_path.exists():
                    template = self._load_template(template_path)
                    if template is not None:
                        template_list.append(template)
                else:
                    print(f"Template não encontrado: {template_path}")

            if template_list:
                self.templates[char] = template_list
                # print(f"Carregado {len(template_list)} template(s) para '{char}'")

    def _load_template(self, template_path: Path) -> Optional[np.ndarray]:
        template = cv2.imread(str(template_path), cv2.IMREAD_GRAYSCALE)
        if template is None:
            print(f"Erro ao carregar template: {template_path}")
            return None
        return template

    def recognize_text_from_roi(self, roi: np.ndarray) -> str:
        import matplotlib.pyplot as plt

        #plt.imshow(roi)
        #plt.axis('off')  # Remove os eixos
        #plt.show()
        img_gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
        all_matches = []

        for char, template_list in self.templates.items():
            for template in template_list:
                w, h = template.shape[::-1]
                res = cv2.matchTemplate(img_gray, template, cv2.TM_CCOEFF_NORMED)
                locations = np.where(res >= self.threshold)
                
                for pt in zip(*locations[::-1]):
                    score = res[pt[1], pt[0]]
                    match_info = {
                        'char': char,
                        'point': pt,
                        'score': score,
                        'width': w,
                        'height': h
                    }

                    all_matches.append(match_info)
                    # LOG: salvar a miniatura da região onde a imagem foi encontrada
                    log_dir = "imgs/log/"
                    all_matches.append(match_info)

                    # 🔹 Recortar a região do caractere detectado no ROI
                    x, y = pt
                    char_crop = roi[y:y+h, x:x+w]  # Recorta a região do caractere

                    # 🔹 Nome do arquivo baseado no caractere e coordenadas
                    filename = f"{log_dir}{char}_{x}_{y}.png"
                    # cv2.imwrite(filename, char_crop)  # Salva a imagem
                    img_with_boxes = roi.copy()  # Cria uma cópia para desenhar as marcações
                    # 🔹 Desenhar o retângulo na imagem de marcação
                    cv2.rectangle(img_with_boxes, (x, y), (x + w, y + h), (0, 255, 0), 2)
                    cv2.putText(img_with_boxes, char, (x, y - 5), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)
                    cv2.imwrite('imgs/log/img_log.png', img_with_boxes)
                   # print()
                    # LOG FIM ||||||||||||||||||||||||||||||||||||||||||||||||||||||||||

        all_matches.sort(key=lambda x: x['score'], reverse=True)
        final_characters = []
        
        for match in all_matches:
            if not self._is_overlapping_with_matches(match, final_characters):
                final_characters.append(match)
        
        final_characters.sort(key=lambda x: x['point'][0])
        return "".join([char['char'] for char in final_characters])


    def convert_to_float(self, text: str) -> float:
        """Converte um texto reconhecido em um número float, lidando com erros."""
        num_str = text.strip().replace(',', '.')  # Caso existam vírgulas como separador decimal

        num_str = text.strip().replace(',', '.')  # Substitui vírgula por ponto  
        num_str = num_str.replace('..', '.')  # Corrige múltiplos pontos seguidos  
        # Substitui '.' isolado por '', e se a string for vazia, assume 0.0
        try:
            return float(num_str) if num_str.replace('.', '', 1).isdigit() else 0.0
        except ValueError:
            return 0.0
        

    def recognize_number_from_roi(self, roi: np.ndarray) -> float:
        """Reconhece um número a partir da ROI da imagem e o converte para float."""
        text = self.recognize_text_from_roi(roi)  # Usa o método de reconhecimento de texto
        return self.convert_to_float(text)  # Converte o resultado para float




    def _is_overlapping_with_matches(self, new_match: dict, existing_matches: list) -> bool:
        new_x, new_y = new_match['point']
        new_w, new_h = new_match['width'], new_match['height']
        
        new_rect = {
            'left': new_x,
            'right': new_x + new_w,
            'top': new_y,
            'bottom': new_y + new_h
        }
        
        for existing in existing_matches:
            ex_x, ex_y = existing['point']
            ex_w, ex_h = existing['width'], existing['height']
            
            exist_rect = {
                'left': ex_x,
                'right': ex_x + ex_w,
                'top': ex_y,
                'bottom': ex_y + ex_h
            }
            
            if not (new_rect['right'] < exist_rect['left'] or 
                    new_rect['left'] > exist_rect['right'] or 
                    new_rect['bottom'] < exist_rect['top'] or 
                    new_rect['top'] > exist_rect['bottom']):
                
                overlap_width = min(new_rect['right'], exist_rect['right']) - max(new_rect['left'], exist_rect['left'])
                overlap_height = min(new_rect['bottom'], exist_rect['bottom']) - max(new_rect['top'], exist_rect['top'])
                overlap_area = overlap_width * overlap_height
                
                min_area = min(new_w * new_h, ex_w * ex_h)
                if overlap_area > 0.25 * min_area:
                    return True
        
        return False
    


@dataclass
class TableInfo:
    table_state: TableState
    players: List[Player]
    #sb_info: Optional[Dict]
    #bb_info: Optional[Dict]
    bb_positions: List[int]

    
class TableRecognizer:
    def __init__(self, config: RoomConfig):
        self.config = config
        self.char_recognizer = CharacterRecognizer(config.template_path)
        self.player_detector = PlayerDetector(config)

        self.dealer_positions = config.dealer_config.positions
        self.dealer_button_color = config.dealer_config.color_rgb 
        self.color_threshold = config.dealer_config.color_threshold

        self.blinds_manager = BlindsManager(min_small_blind=1, min_big_blind=2)
        
    def detect_dealer_position(self, image: np.ndarray) -> int:
        for position, (x, y) in self.dealer_positions.items():
            pixel_color = image[y, x]
            if np.all(np.abs(pixel_color - self.dealer_button_color) < self.color_threshold):
                return position
        return -1

    def process_table(self, image: np.ndarray) -> TableState:
        """
        Process the poker table image and extract all relevant information.

        Args:
            image: The table screenshot as a numpy array
            
        Returns:
            TableState object containing all recognized information
        """
        players = self.player_detector.detect_players(image)
        roi_config = self.config.roi_config

        # Função auxiliar genérica para processamento de ROIs
        def process_rois(roi_dict, category, processor, attr_name=None):
            if not roi_dict:
                return None
                
            self.char_recognizer.load_templates(category)
            
            # Para ROIs de jogador (com posição no nome)
            if attr_name:
                for name, (x, y, w, h) in roi_dict.items():
                    roi = image[y:y+h, x:x+w]
                    result = processor(roi)
                    position = int(name.split('_')[1])
                    if result=='CrackeDeuces':
                        print('')
                    if position < len(players):
                        setattr(players[position], attr_name, result)
                return None
            # Para ROIs únicos (pot/smallpot)
            else:
                # Processa apenas a primeira ROI (assumindo que há apenas uma)
                x, y, w, h = next(iter(roi_dict.values()))
                roi = image[y:y+h, x:x+w]
                return processor(roi)

        # Processamento simplificado para todas as regiões
        process_rois(roi_config.stacks, RecognitionCategory.STACK, 
                    self.char_recognizer.recognize_number_from_roi, 'stack')

        process_rois(roi_config.bets, RecognitionCategory.BET, 
                    self.char_recognizer.recognize_number_from_roi, 'current_bet')

        process_rois(roi_config.names, RecognitionCategory.NAMES, 
                    self.char_recognizer.recognize_text_from_roi, 'name')

        # Processamento unificado para pot e smallpot
        pot = process_rois(roi_config.pot, RecognitionCategory.POT, 
                        self.char_recognizer.recognize_text_from_roi) or ""

        small_pot = process_rois(roi_config.smallpot, RecognitionCategory.SMALLPOT, 
                                self.char_recognizer.recognize_text_from_roi) or ""

        # Detect dealer position
        dealer_position = self.detect_dealer_position(image)

        # Identifica Sb e BB in Players
        players = self.blinds_manager.identify_blinds(players, dealer_position)

        # Create debug image if needed
        if self.config.debug_mode:
            self._create_debug_image(image, roi_config, dealer_position, players)
#config: RoomConfig, players: List[Player], image: np.ndarray, player_positions: dict, template_path: str, threshold: float
        players = is_player_present(
            self.config,
            players, 
            image, 
            self.config.player_detection_config.positions,
            self.config.template_path,
            self.config.player_detection_config.threshold
        )

        return TableState(
            pot=pot,
            small_pot=small_pot,
            dealer_position=dealer_position,
            players=players
        )

    def _create_debug_image(self, image: np.ndarray, config: RoomConfig, dealer_position: int, players: list):
        debug_image = image.copy()
        roi_config = config

        # Draw ROIs for stacks
        for name, (x, y, w, h) in roi_config.stacks.items():
            cv2.rectangle(debug_image, (x, y), (x+w, y+h), (0, 255, 0), 2)
            position = int(name.split('_')[1])
            stack_value = players[position].stack if position < len(players) else 0
            cv2.putText(debug_image, f"Stack: {stack_value}", (x, y+h+15), 
                      cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)

        # Draw ROIs for bets
        for name, (x, y, w, h) in roi_config.bets.items():
            cv2.rectangle(debug_image, (x, y), (x+w, y+h), (255, 0, 0), 2)
            position = int(name.split('_')[1])
            bet_value = players[position].current_bet if position < len(players) else 0
            cv2.putText(debug_image, f"Bet: {bet_value}", (x, y-5), 
                      cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 0, 0), 1)

        # Draw ROIs for names
        for name, (x, y, w, h) in roi_config.names.items():
            # Desenha o retângulo ao redor da área do nome
            cv2.rectangle(debug_image, (x, y), (x+w, y+h), (0, 0, 255), 2)
            
            position = int(name.split('_')[1])
            player_name = players[position].name if position < len(players) else ""
            
            # Configurações de texto melhoradas
            text = f"{player_name}"
            font = cv2.FONT_HERSHEY_DUPLEX  # Fonte mais limpa e moderna
            font_scale = 0.6
            thickness = 1
            text_color = (200, 255, 200)  # Verde claro suave (BGR)
            bg_color = (40, 40, 40)      # Cinza escuro para fundo
            
            # Calcula o tamanho do texto para criar o fundo
            (text_width, text_height), baseline = cv2.getTextSize(
                text, font, font_scale, thickness
            )
            
            # Define as coordenadas do retângulo de fundo
            bg_x1 = x
            bg_y1 = y - text_height - 10  # 10px acima do topo do retângulo
            bg_x2 = x + text_width
            bg_y2 = y - 5
            
            # Desenha o retângulo de fundo
            cv2.rectangle(
                debug_image, 
                (bg_x1, bg_y1), 
                (bg_x2, bg_y2), 
                bg_color, 
                -1  # Preenchido
            )
            
            # Desenha o texto sobre o fundo
            cv2.putText(
                debug_image, 
                text, 
                (x, y - 8),  # Posição ajustada
                font,
                font_scale,
                text_color,
                thickness,
                lineType=cv2.LINE_AA  # Anti-aliasing para melhor suavização
            )

        # Draw ROI for pot
        for name, (x, y, w, h) in roi_config.pot.items():
            cv2.rectangle(debug_image, (x, y), (x+w, y+h), (255, 255, 0), 2)
            cv2.putText(debug_image, f"Pot", (x, y-5), 
                      cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 0), 1)

        # Draw ROI for small pot
        for name, (x, y, w, h) in roi_config.smallpot.items():
            cv2.rectangle(debug_image, (x, y), (x+w, y+h), (0, 255, 255), 2)
            cv2.putText(debug_image, f"Small Pot", (x, y-5), 
                      cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 255), 1)

        # Mark dealer position if detected
        if dealer_position != -1 and dealer_position in self.config.dealer_config.positions:
            x, y = self.config.dealer_config.positions[dealer_position]
            cv2.circle(debug_image, (x, y), 5, (0, 0, 255), -1)
            cv2.putText(debug_image, f"Dealer {dealer_position}", (x+10, y), 
                      cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 1)
        
        # Mark SB and BB positions
        for player in players:
            pos_label = ''
            if player.pos_preflop:
                pos_label = player.pos_preflop.value  # Extrai o valor string: 'SB' ou 'BB'

            if pos_label in ['SB', 'BB']:
                # Assumindo que as posições estão mapeadas como chaves em self.config.dealer_config.positions
                if player.position in self.config.dealer_config.positions:
                    x, y = self.config.dealer_config.positions[player.position]
                    color = (0, 255, 255) if pos_label == 'SB' else (255, 0, 0)  # Amarelo para SB, Azul para BB
                    cv2.circle(debug_image, (x, y), 5, color, -1)
                    cv2.putText(debug_image, f"{pos_label}", (x + 10, y),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 1)

        # Save debug image
        print("Debug Mode ON: Image save: debug_table_recognition.png" )
        cv2.imwrite("debug_table_recognition.png", debug_image)

class TableAnalyzer:
    def __init__(self, config: RoomConfig):
        self.table_config = config
        self.blinds_manager = BlindsManager(min_small_blind=1, min_big_blind=2)
        self.char_recognizer = CharacterRecognizer(config.template_path)
        self.table_recognizer = TableRecognizer(config)
        self.player_detector = PlayerDetector(config)
        
    def analyze_table(self, snapshot: Optional[np.ndarray] = None) -> TableInfo:
        if snapshot is None:
            # For testing purposes, load a sample image
            snapshot = cv2.imread(self.table_config.sample_image_path)
            if snapshot is None:
                raise ValueError("No snapshot provided and couldn't load sample image")
   
        active_players = self.player_detector.detect_players(snapshot)        
        table_state = self.table_recognizer.process_table(snapshot)

        table_info = TableInfo(
            table_state=table_state,
            players=active_players,
            bb_positions=[]
        )
   
        bb_positions = self.blinds_manager.validate_preflop_bets(active_players, bb_amount=2)
        
        # Atualiza o objeto TableInfo
        table_info.bb_positions = bb_positions

        return table_info



class PlayerDetector:
    def __init__(self, config: RoomConfig):
        self.absent_template = cv2.imread(f"{config.template_path}/others/assento_vazio.png", cv2.IMREAD_GRAYSCALE)
        self.threshold = config.player_detection_config.threshold
        self.player_positions = config.player_detection_config.positions

    def detect_players(self, image: np.ndarray) -> List[Player]:
        players = []
        gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        filename = os.path.join('imgs/log', f"gray_image_{timestamp}.png")
        # cv2.imwrite(filename, gray_image)
        
        for pos, roi in self.player_positions.items():
            x, y, w, h = roi #room_config.py player_detection_config
            region = gray_image[y:y+h, x:x+w]
            
            is_present = True
            if self.absent_template is not None:
                result = cv2.matchTemplate(region, self.absent_template, cv2.TM_CCOEFF_NORMED)
                if np.max(result) >= self.threshold:
                    is_present = False
  
            players.append(Player(
                is_active= False,
                name = '',
                position=pos,
                pos_preflop='',
                is_present=is_present,
                stack=0.0,
                current_bet=0.0
            ))

        return players

def is_player_present(config: RoomConfig, players: List[Player], image: np.ndarray, player_positions: dict, template_path: str, threshold: float) -> List[Player]:
    """
    Detecta se o player está presente na mesa usando template de assento vazio.
    """
    absent_template = cv2.imread(f"{config.template_path}/others/assento_vazio.png", cv2.IMREAD_GRAYSCALE)
    gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    for player in players:
        pos = player.position
        if pos in player_positions:
            x, y, w, h = player_positions[pos]
            region = gray_image[y:y+h, x:x+w]
            
            is_present = True
            if absent_template is not None:
                result = cv2.matchTemplate(region, absent_template, cv2.TM_CCOEFF_NORMED)
                if np.max(result) >= threshold:
                    is_present = False
            
            player.is_present = is_present

    return players
