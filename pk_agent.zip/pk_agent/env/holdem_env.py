from slumbot_agent import SlumbotAgent
from utils.action_parser import ParseAction

class HoldemEnv:
    def __init__(self, username=None, password=None):
        self.slumbot = SlumbotAgent(username, password)
        self.state = None
        self.done = False
        self.reward = 0
        self.info = {}

    def reset(self):
        self.state = self.slumbot.new_hand()
        self.done = False
        self.reward = 0
        self.info = {}
        return self._get_observation()

    def step(self, action):
        if self.done:
            raise Exception("Call reset before calling step again.")

        self.state = self.slumbot.act(action)
        winnings = self.state.get('winnings')

        if winnings is not None:
            self.done = True
            self.reward = winnings
            self.info = {'result': 'win' if winnings > 0 else 'lose'}
        
        return self._get_observation(), self.reward, self.done, self.info

    def _get_observation(self):
        return {
            'hole_cards': [str(card) for card in self.state.get('hole_cards', [])],
            'board': [str(card) for card in self.state.get('board', [])],
            'action': str(self.state.get('action', ''))
        }

    def sample_action(self):
        parsed = ParseAction(self.state['action'])
        return 'c' if parsed.get('last_bettor', -1) != -1 else 'k'
