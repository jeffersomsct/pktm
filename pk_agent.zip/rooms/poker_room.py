from . import BasePokerRoom
#from core.table_analyzer import TableAnalyzer
from poker_table_recognizer import TableAnalyzer
from config.room_config import get_swc_poker_config, get_acr_poker_config, get_bodog_poker_config



class PokerRoom(BasePokerRoom):
    def __init__(self, room_name: str):
        '''
        nomes possiveis:
         rooms = {
            "SwC Poker - usuário jeffpk": SwC Poker
            "Bodog.com - Poker Lobby": Bodog Poker
            "Lobby ACR Poker Conectado como jeffersom": ACR Poker
        }
        '''
        self.room_name = room_name
        self.room_config = None
        # Definir a configuração com base no nome da sala
        if "SwC Poker" in room_name:
            self.room_config = get_swc_poker_config()
        elif "Bodog" in room_name:
            self.room_config = get_bodog_poker_config()
        elif "ACR Poker" in room_name:
            self.room_config = get_acr_poker_config()
        else:
            # Configuração padrão caso o nome da sala não seja reconhecido
            print(f"Aviso: Nome de sala não reconhecido: {room_name}. Usando configuração padrão.")
            
        self.analyzer = TableAnalyzer(self.room_config)
    
    def analyze_table(self, snapshot):
        return self.analyzer.analyze_table()
    
    def get_room_config(self):
        return self.room_config