import win32gui
import win32process


def get_all_child_windows(parent_handle):
    """
    Obtém todas as janelas filhas do handle da janela principal.
    """
    child_windows = []
    
    def callback(hwnd, _):
        title = win32gui.GetWindowText(hwnd).strip()  # Obtém título
        if title:  # Ignorar janelas sem título
            child_windows.append((hwnd, title))
        return True  # Continuar a enumeração
    
    win32gui.EnumChildWindows(parent_handle, callback, None)
    return child_windows

def get_existing_windows(process_id):
    existing_windows = []
    
    def callback(hwnd, _):
        # Verifica se a janela está visível e pertence ao processo correto
        if win32gui.IsWindowVisible(hwnd):
            _, wnd_process_id = win32process.GetWindowThreadProcessId(hwnd)
            if wnd_process_id == process_id:
                title = win32gui.GetWindowText(hwnd).strip()  # Remove espaços
                if title:  # Ignorar janelas sem título
                    existing_windows.append((hwnd, title))
        return True  # Continuar a enumeração
    
    win32gui.EnumWindows(callback, None)
    return existing_windows


def search_parent_window(window_title):
    # Nome da janela principal do jogo
    # window_title = "SwC Poker"
    main_handle = win32gui.FindWindow(None, window_title)

    if main_handle:
        print(f"Handle principal encontrado: {main_handle}")
        
        # Obter todas as janelas filhas, sem restrição de visibilidade
        child_windows = get_all_child_windows(main_handle)
        # print("Todas as janelas filhas associadas:")
        # for hwnd, title in child_windows:
            # print(f"Handle: {hwnd}, Título: {title}")
        
        # Obtém o ID do processo do jogo
        _, process_id = win32process.GetWindowThreadProcessId(main_handle)
        # print(f"Process ID do jogo: {process_id}")
        
        # Lista todas as janelas associadas ao processo, sem restrição
        all_windows = get_existing_windows(process_id)
        print("\nTodas as janelas associadas ao processo:")
        #for hwnd, title in all_windows:
            #print(f"Handle: {hwnd}, Título: {title}")
        return all_windows
        
        

    else:
        print("Janela principal do jogo não encontrada.")
